Vorbereitung:
  1. Ausführen des SQL-Scripts /sql/init.sql
  2. Eintragen des Pfades unserer Anwendung am Server in der Base.php

Default-User:
  Username: admin
  Password: secret

  Username: author
  Password: password

  Username: user
  Password: password

  Username: guest
  Password: password
