Wir verwenden MySQL zur Persistierung der Daten.
/sql/init.sql muss einmalig ausgeführt werden um volle Funktionsfähigkeit zu ermöglichen.

Default-User:
  Username: admin
  Password: secret

  Username: author
  Password: password

  Username: user
  Password: password

  Username: guest
  Password: password
