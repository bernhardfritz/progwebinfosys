Wir verwenden MySQL zur Persistierung der Daten.
/sql/init.sql muss einmalig ausgeführt werden um volle Funktionsfähigkeit zu ermöglichen.
