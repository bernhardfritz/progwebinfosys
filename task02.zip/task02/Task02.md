# Task 1:

Abgabedatum - 19.10.2015 bis 12:00 Uhr

## Doing

Bitte beachten, dass im Rahmen des "MyBlog"-Systems die Verwendung von Frameworks/Libraries (egal ob HTML, CSS, PHP, ...) nicht erlaubt ist!

### MyBlog - Grundgerüst erstellen
Startseite mit Blogeinträgen (sortiert nach Erstellungsdatum)

### MyBlog - Formular zum Erstellen/Ändern von Einträgen
Formular aus einem eindeutigen Titel, den Beitragsinhalt und Keywords.
Des Weiteren sollen Autor, Erstellungsdatum und Änderungsdatum persistiert werden.

### MyBlog - Lösung zum Löschen von Beiträgen
Als Teil des Bearbeitungs-Formulars (oder als Button, oder als...)

### MyBlog - Speichern der Daten in die HTTP-Session
Die Daten sollen auch nach dem Beenden des Browsers erhalten bleiben.

## Reading:

### PHP
[PHP Manual](http://php.net/manual/de)

